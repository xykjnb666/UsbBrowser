# U盘浏览器（Android / Jetpack Compose）

当前项目提供 Material 3 文件浏览界面、SAF 目录授权、本机与 U 盘目录之间的文件/文件夹复制移动、视频播放、可选主题色与 Android 12+ 壁纸动态取色。

## 构建 APK

项目已附 GitHub Actions 工作流：`.github/workflows/build-apk.yml`。

1. 将本项目目录中的所有文件上传到 GitHub 仓库根目录。
2. 打开仓库的 **Actions** 页面。
3. 选择 **Build Android APK**，点击 **Run workflow**。
4. 构建成功后打开本次运行记录，在 **Artifacts** 中下载 `UsbBrowser-debug-apk`，解压即可得到 `app-debug.apk`。

本项目使用 Gradle 8.13、JDK 17、Android SDK 36。

## 重要功能边界

- 文件访问使用 Android 系统 Storage Access Framework（SAF）。首次使用时分别选择本机目录和 U 盘目录并授予读写权限。是否能显示 U 盘取决于设备 OTG 支持及系统文件选择器。
- 当前代码保留了 libaums 与 Shizuku 依赖，并会在 Shizuku 服务可用时请求授权；但尚未实现基于 libaums 的底层 USB Mass Storage 自动枚举/挂载，也没有通过 Shizuku 直接访问 `/mnt/media_rw`。不能把当前版本描述为已完成自动 OTG 驱动。
- 传输采用复制完成后再删除源文件的顺序，避免目录复制中途失败时提前删除尚未复制的源文件。若目标设备在传输期间断开，仍应检查目标端是否有不完整副本。
- 这是 debug 构建配置，APK 未签名为 Play 商店发布版。

## 项目结构

- `app/src/main/java/com/example/usbbrowser/MainActivity.kt`：Compose UI、SAF 文件操作、Media3 播放器。
- `app/src/main/AndroidManifest.xml`：Activity、USB Host 特性与 Shizuku Provider。
- `app/build.gradle.kts`：Android、Compose、Media3、Shizuku、libaums 依赖。
- `.github/workflows/build-apk.yml`：云端构建 APK。

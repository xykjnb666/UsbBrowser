package com.example.usbbrowser

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.text.DateFormat
import java.util.Date

private const val REQ_SHIZUKU = 731

class MainActivity : ComponentActivity() {
    private val permissionListener = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == REQ_SHIZUKU) {
            getSharedPreferences("state", MODE_PRIVATE).edit()
                .putBoolean("shizuku", result == android.content.pm.PackageManager.PERMISSION_GRANTED).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        // 自动请求：仅在 Shizuku 服务已启动且尚未授权时请求。
        runCatching {
            if (Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) Shizuku.requestPermission(REQ_SHIZUKU)
        }
        setContent { UsbBrowserRoot() }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }
}

private enum class StorageTab { DEVICE, USB }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UsbBrowserRoot() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("roots", ComponentActivity.MODE_PRIVATE) }
    var localUri by remember { mutableStateOf(prefs.getString("local", null)?.let(Uri::parse)) }
    var usbUri by remember { mutableStateOf(prefs.getString("usb", null)?.let(Uri::parse)) }
    var tab by remember { mutableStateOf(StorageTab.DEVICE) }
    var currentDirectory by remember { mutableStateOf<DocumentFile?>(null) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var refresh by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var message by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Uri?>(null) }
    var showPalette by remember { mutableStateOf(false) }
    var palette by remember { mutableStateOf(prefs.getString("palette", "monet") ?: "monet") }
    val scope = rememberCoroutineScope()

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            if (tab == StorageTab.DEVICE) {
                localUri = uri
                prefs.edit().putString("local", uri.toString()).apply()
            } else {
                usbUri = uri
                prefs.edit().putString("usb", uri.toString()).apply()
            }
            currentDirectory = DocumentFile.fromTreeUri(context, uri)
            selected = emptySet()
            refresh++
        }
    }

    val rootUri = if (tab == StorageTab.DEVICE) localUri else usbUri
    val rootDirectory = remember(rootUri) { rootUri?.let { DocumentFile.fromTreeUri(context, it) } }
    val directory = currentDirectory ?: rootDirectory
    val entries = remember(directory, refresh) {
        directory?.listFiles()?.sortedWith(compareBy<DocumentFile> { !it.isDirectory }.thenBy { it.name?.lowercase().orEmpty() })
            ?: emptyList()
    }

    if (playing != null) {
        VideoScreen(uri = playing!!, onBack = { playing = null })
        return
    }

    val appColors = when (palette) {
        "monet" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) dynamicLightColorScheme(context)
            else lightColorScheme(primary = Color(0xFF0B57D0), secondary = Color(0xFF006A60))
        "mint" -> lightColorScheme(primary = Color(0xFF087F6E), secondary = Color(0xFF526B55), background = Color(0xFFF5FBF7), surface = Color(0xFFF5FBF7))
        "lavender" -> lightColorScheme(primary = Color(0xFF6750A4), secondary = Color(0xFF625B71), background = Color(0xFFFAF7FF), surface = Color(0xFFFAF7FF))
        "pink" -> lightColorScheme(primary = Color(0xFFB32667), secondary = Color(0xFF79505F), background = Color(0xFFFFF7FA), surface = Color(0xFFFFF7FA))
        "orange" -> lightColorScheme(primary = Color(0xFF9A5700), secondary = Color(0xFF765A3B), background = Color(0xFFFFF8F2), surface = Color(0xFFFFF8F2))
        else -> lightColorScheme(primary = Color(0xFF0B57D0), secondary = Color(0xFF006A60), background = Color(0xFFF8F9FF), surface = Color(0xFFF8F9FF), surfaceVariant = Color(0xFFE8EEF8))
    }
    MaterialTheme(colorScheme = appColors) {
        if (showPalette) {
            AlertDialog(
                onDismissRequest = { showPalette = false },
                title = { Text("主题颜色") },
                text = {
                    Column {
                        listOf("monet" to "跟随壁纸（莫奈取色）", "blue" to "Google 蓝", "mint" to "薄荷绿", "lavender" to "薰衣草紫", "pink" to "樱花粉", "orange" to "暖橙色").forEach { (key, title) ->
                            Row(Modifier.fillMaxWidth().clickable {
                                palette = key
                                prefs.edit().putString("palette", key).apply()
                                showPalette = false
                            }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = palette == key, onClick = {
                                    palette = key
                                    prefs.edit().putString("palette", key).apply()
                                    showPalette = false
                                })
                                Spacer(Modifier.width(8.dp))
                                Text(title)
                            }
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showPalette = false }) { Text("关闭") } }
            )
        }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("文件", fontWeight = FontWeight.SemiBold)
                            Text(if (tab == StorageTab.DEVICE) "本机存储" else "USB OTG 存储",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    navigationIcon = {
                        Icon(Icons.Default.FolderCopy, contentDescription = null,
                            modifier = Modifier.padding(start = 16.dp).size(27.dp),
                            tint = MaterialTheme.colorScheme.primary)
                    },
                    actions = {
                        IconButton(onClick = { showPalette = true }) { Icon(Icons.Default.Palette, "主题颜色") }
                        IconButton(onClick = { refresh++ }) { Icon(Icons.Default.Refresh, "刷新") }
                        IconButton(onClick = { folderPicker.launch(rootUri) }) { Icon(Icons.Default.FolderOpen, "选择目录") }
                    }
                )
            },
            bottomBar = {
                if (selected.isNotEmpty()) {
                    Surface(shadowElevation = 8.dp, color = MaterialTheme.colorScheme.surface) {
                        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = { selected = emptySet() }, modifier = Modifier.weight(1f)) {
                                Text("取消 (${selected.size})")
                            }
                            Button(
                                enabled = !busy && (if (tab == StorageTab.DEVICE) usbUri != null else localUri != null),
                                onClick = {
                                    val targetRoot = if (tab == StorageTab.DEVICE) usbUri else localUri
                                    val target = targetRoot?.let { DocumentFile.fromTreeUri(context, it) }
                                    if (target == null) { message = "请先选择目标存储目录"; return@Button }
                                    val sources = entries.filter { it.uri.toString() in selected }
                                    busy = true
                                    progress = 0f
                                    scope.launch {
                                        var ok = 0
                                        var failed = 0
                                        sources.forEachIndexed { index, source ->
                                            val result = withContext(Dispatchers.IO) {
                                                copyDocument(context, source, target, move = true)
                                            }
                                            if (result) ok++ else failed++
                                            progress = (index + 1).toFloat() / sources.size.coerceAtLeast(1)
                                        }
                                        busy = false
                                        selected = emptySet()
                                        refresh++
                                        message = "完成：成功 $ok 项，失败 $failed 项"
                                    }
                                },
                                modifier = Modifier.weight(1.5f)
                            ) {
                                Icon(Icons.Default.DriveFileMove, null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (tab == StorageTab.DEVICE) "移动到 U 盘" else "移动到本机")
                            }
                        }
                    }
                }
            },
            floatingActionButton = {
                if (selected.isEmpty()) {
                    ExtendedFloatingActionButton(
                        onClick = { folderPicker.launch(rootUri) },
                        icon = { Icon(Icons.Default.Add, null) },
                        text = { Text(if (rootUri == null) "选择存储目录" else "更换目录") }
                    )
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp)) {
                    FilterTab("本机", tab == StorageTab.DEVICE, Modifier.weight(1f)) {
                        tab = StorageTab.DEVICE; currentDirectory = null; selected = emptySet()
                    }
                    FilterTab("U盘", tab == StorageTab.USB, Modifier.weight(1f)) {
                        tab = StorageTab.USB; currentDirectory = null; selected = emptySet()
                    }
                }
                if (busy) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    Text("正在传输 ${(progress * 100).toInt()}%", Modifier.padding(horizontal = 18.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelMedium)
                }
                val label = directory?.name ?: if (rootUri == null) "尚未选择目录" else "存储目录"
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Folder, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.weight(1f))
                    Text("${entries.size} 项", style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (rootUri == null) {
                    EmptyState(
                        icon = if (tab == StorageTab.DEVICE) Icons.Default.PhoneAndroid else Icons.Default.Usb,
                        title = if (tab == StorageTab.DEVICE) "选择本机存储目录" else "连接并选择 U 盘",
                        subtitle = "使用 Android 系统文件选择器授权目录访问。授权后可浏览、播放和传输文件。",
                        action = "选择目录",
                        onAction = { folderPicker.launch(null) }
                    )
                } else if (entries.isEmpty()) {
                    EmptyState(Icons.Default.FolderOpen, "这里还没有文件", "此目录为空，或当前设备尚未读取到内容。", null, {})
                } else {
                    LazyColumn(contentPadding = PaddingValues(bottom = 96.dp)) {
                        items(entries, key = { it.uri.toString() }) { item ->
                            val key = item.uri.toString()
                            val isSelected = key in selected
                            val isVideo = item.type?.startsWith("video/") == true
                            ListItem(
                                headlineContent = {
                                    Text(item.name ?: "未命名", maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal)
                                },
                                supportingContent = {
                                    Text(if (item.isDirectory) "文件夹" else "${formatSize(item.length())} · ${item.type ?: "文件"}",
                                        style = MaterialTheme.typography.bodySmall)
                                },
                                leadingContent = {
                                    Surface(shape = RoundedCornerShape(14.dp),
                                        color = if (item.isDirectory) Color(0xFFE8F0FE) else MaterialTheme.colorScheme.surfaceVariant) {
                                        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
                                            Icon(
                                                when {
                                                    item.isDirectory -> Icons.Default.Folder
                                                    isVideo -> Icons.Default.PlayCircle
                                                    else -> Icons.Default.InsertDriveFile
                                                }, null,
                                                tint = if (item.isDirectory) Color(0xFF1967D2) else MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(25.dp)
                                            )
                                        }
                                    }
                                },
                                trailingContent = {
                                    Checkbox(checked = isSelected, onCheckedChange = { checked ->
                                        selected = if (checked) selected + key else selected - key
                                    })
                                },
                                modifier = Modifier.clickable {
                                    when {
                                        item.isDirectory -> { currentDirectory = item; selected = emptySet(); refresh++ }
                                        isVideo -> playing = item.uri
                                        else -> selected = if (isSelected) selected - key else selected + key
                                    }
                                }
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .8f),
                                thickness = .7.dp)
                        }
                    }
                }
            }
        }
        if (message != null) {
            val text = message!!
            LaunchedEffect(text) { kotlinx.coroutines.delay(3500); if (message == text) message = null }
            SnackbarHost(hostState = remember { SnackbarHostState() }, modifier = Modifier)
            // Snackbar is surfaced as a compact bottom message.
            Surface(Modifier.fillMaxWidth().padding(12.dp), shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.inverseSurface, shadowElevation = 6.dp) {
                Text(text, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.inverseOnSurface)
            }
        }
    }
}

@Composable
private fun FilterTab(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.clip(CircleShape).clickable(onClick = onClick),
        color = if (selected) MaterialTheme.colorScheme.surface else Color.Transparent,
        shape = CircleShape, shadowElevation = if (selected) 1.dp else 0.dp) {
        Box(Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
            Text(text, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
        }
    }
}

@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    action: String?,
    onAction: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer) {
            Icon(icon, null, Modifier.padding(22.dp).size(42.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
        }
        Spacer(Modifier.height(20.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) {
            Spacer(Modifier.height(20.dp))
            Button(onClick = onAction) { Text(action) }
        }
    }
}

private suspend fun copyDocument(
    context: android.content.Context,
    source: DocumentFile,
    destinationDir: DocumentFile,
    move: Boolean
): Boolean = withContext(Dispatchers.IO) {
    try {
        val name = source.name ?: "unnamed"
        val destination = if (source.isDirectory) {
            destinationDir.findFile(name) ?: destinationDir.createDirectory(name)
        } else {
            destinationDir.createFile(source.type ?: "application/octet-stream", uniqueName(destinationDir, name))
        } ?: return@withContext false

        if (source.isDirectory) {
            source.listFiles().forEach { child ->
                if (!copyDocument(context, child, destination, move = false)) return@withContext false
            }
        } else {
            context.contentResolver.openInputStream(source.uri).use { input ->
                context.contentResolver.openOutputStream(destination.uri, "w").use { output ->
                    if (input == null || output == null) return@withContext false
                    val buffer = ByteArray(256 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                    }
                    output.flush()
                }
            }
        }
        if (move) deleteDocumentTree(source) else true
    } catch (_: Exception) { false }
}

private fun deleteDocumentTree(document: DocumentFile): Boolean {
    return try {
        if (document.isDirectory) {
            val childrenDeleted = document.listFiles().all { child -> deleteDocumentTree(child) }
            childrenDeleted && document.delete()
        } else document.delete()
    } catch (_: Exception) { false }
}

private fun uniqueName(dir: DocumentFile, name: String): String {
    if (dir.findFile(name) == null) return name
    val dot = name.lastIndexOf('.').takeIf { it > 0 } ?: name.length
    val base = name.substring(0, dot)
    val ext = name.substring(dot)
    var i = 1
    while (dir.findFile("$base ($i)$ext") != null) i++
    return "$base ($i)$ext"
}

private fun formatSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024L * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}

@Composable
private fun VideoScreen(uri: Uri, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text("视频播放", color = Color.White, style = MaterialTheme.typography.titleMedium)
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(0.dp)),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = player
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    useController = true
                }
            },
            update = { it.player = player }
        )
        Text("视频按原始比例适配屏幕", Modifier.align(Alignment.CenterHorizontally).navigationBarsPadding().padding(16.dp),
            color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
    }
}
